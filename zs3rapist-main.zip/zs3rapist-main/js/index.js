// Funkcja do otwierania panelu bocznego
const openNav = () => {
	document.getElementById('inputPanel').style.width = '250px'
	document.querySelector('.closebtn').style.display = 'block' // Pokaż przycisk
}

const closeNav = () => {
	document.getElementById('inputPanel').style.width = '0'
	document.querySelector('.closebtn').style.display = 'none' // Ukryj przycisk
}

// Funkcja do edycji lekcji
const editLesson = () => {
	const lessonNumber = document.getElementById('lessonToEdit').value
	const newLessonName = document.getElementById('newLessonName').value
	const newLessonRoom = document.getElementById('newLessonRoom').value

	// Wybór odpowiedniego diva na podstawie numeru lekcji
	const lessonDiv = document.querySelector(`.lesson.${getLessonClass(lessonNumber)}`)
	if (lessonDiv) {
		// Zmiana nazwy przedmiotu
		const titleSpan = lessonDiv.querySelector('.title')
		const timeRoomSpan = titleSpan.querySelector('.timeroom')
		titleSpan.firstChild.textContent = newLessonName // Zmienia tylko nazwę przedmiotu
		if (newLessonRoom) {
			const time = timeRoomSpan.textContent.split(',')[0] // Zachowuje czas
			timeRoomSpan.textContent = `${time}, sala ${newLessonRoom}` // Zmienia tylko numer sali
		}
	} else {
		alert('Nie znaleziono lekcji o podanym numerze.')
	}

	closeNav()
}

const removeLesson = () => {
	const lessonNumber = document.getElementById('lessonToRemove').value
	const lessonDiv = document.querySelector(`.lesson.${getLessonClass(lessonNumber)}`)
	if (lessonDiv) {
		lessonDiv.remove()
	} else {
		alert('Nie znaleziono lekcji o podanym numerze.')
	}
}

// Funkcja pomocnicza do uzyskania klasy na podstawie numeru lekcji
const getLessonClass = number => {
	switch (number) {
		case '1':
			return 'firstlesson'
		case '2':
			return 'secondlesson'
		case '3':
			return 'thirdlesson'
		case '4':
			return 'fourthlesson'
		case '5':
			return 'fifthlesson'
		case '6':
			return 'sixthlesson'
		case '7':
			return 'seventhlesson'
		case '8':
			return 'eighthlesson'
		default:
			return ''
	}
}

const cancelLesson = () => {
	const lessonNumber = document.getElementById('lessonToCancel').value
	const lessonDiv = document.querySelector(`.lesson.${getLessonClass(lessonNumber)}`)
	if (lessonDiv) {
		const titleSpan = lessonDiv.querySelector('.title')
		const canceledTitle = document.createElement('span')
		canceledTitle.textContent = titleSpan.firstChild.textContent // Przenosimy nazwę przedmiotu
		canceledTitle.style.textDecoration = 'line-through'
		canceledTitle.style.fontWeight = 'bold'

		// Zastąpienie oryginalnego tekstu nowym elementem
		titleSpan.firstChild.replaceWith(canceledTitle)

		// Dodajemy etykietę "Odwołana" tylko jeśli jeszcze nie istnieje
		if (!lessonDiv.querySelector('.cancel-text')) {
			const br = document.createElement('br') // Tworzymy element <br>
			const cancelText = document.createElement('span')
			cancelText.textContent = 'Odwołana'
			cancelText.className = 'cancel-text' // Klasa dla nowego spana z tekstem "Odwołana"

			// Dodajemy najpierw <br>, a potem napis "Odwołana"
			titleSpan.appendChild(br)
			titleSpan.appendChild(cancelText)
		}

		// Dodanie fioletowego paska tylko jeśli jeszcze nie istnieje
		if (!lessonDiv.querySelector('.cancel-bar')) {
			const cancelBar = document.createElement('div')
			cancelBar.className = 'cancel-bar'
			lessonDiv.prepend(cancelBar)
		}
	} else {
		alert('Nie znaleziono lekcji o podanym numerze.')
	}
}

// Funkcja do aktualizacji dat tygodnia
function updateWeekDates() {
	const today = new Date()
	const dayOfWeek = today.getDay()
	const monday = new Date(today)
	monday.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1))

	const dayElements = document.querySelectorAll('.week-nav li')
	for (let i = 0; i < 7; i++) {
		const dayDate = new Date(monday)
		dayDate.setDate(monday.getDate() + i)
		const dateFormatted = `${dayDate.getDate()}`.padStart(2, '0')
		const dayName = dayElements[i].innerText.split('<br>')[0] // Pobiera nazwę dnia
		dayElements[i].innerHTML = `${dayName}<br>${dateFormatted}` // Dodaje <br> po nazwie dnia
	}
}

// Funkcja do wyróżniania bieżącego dnia tygodnia
function highlightCurrentDay() {
	const currentDay = new Date().getDay()
	const days = ['Niedz.', 'Pon.', 'Wt.', 'Śr.', 'Czw.', 'Pt.', 'Sob.']
	const dayElements = document.querySelectorAll('.week-nav li')

	dayElements.forEach((element, index) => {
		if (days[currentDay] === element.innerText.split('\n')[0]) {
			element.style.fontWeight = 'bold'
		}
	})
}

// Inicjalizacja funkcji po załadowaniu strony
document.addEventListener('DOMContentLoaded', function () {
	updateWeekDates()
	highlightCurrentDay()

	// Przypisanie funkcji do przycisków i ikon
	document.getElementById('editLessonButton').addEventListener('click', editLesson)
	document.querySelector('.openInput').addEventListener('dblclick', openNav)
})
